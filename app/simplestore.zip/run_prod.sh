# READ ENV BY NODEMOD
cp src/core/rce/libs/rce.h /tmp
sudo nodemon bin/app.js
