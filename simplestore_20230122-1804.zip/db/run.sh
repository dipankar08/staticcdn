mkdir ./data
echo 'running mongod...'
mongod --config ./mongod.conf 
# echo 'running redis server..'
# redis-server & 

echo 'all done'
